<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>WK8 Challenge</title>
</head>
<body>
    <h1>WK8 Challenge</h1>
    <ul>
        <li><a href="send_email.php">Part 1 - Send an Email</a></li>
        <li><a href="upload.php">Part 2 - File Upload</a></li>
        <li><a href="interactive.php">Part 3 - Interactive App</a></li>
        <li><a href="headers.php">Part 4 - HTTP Headers</a></li>
        <li><a href="datetime.php">Part 5 - Date & Time</a></li>
        <li><a href="db_transactions.php">Part 6 - DB Transactions</a></li>
    </ul>
</body>
</html>
